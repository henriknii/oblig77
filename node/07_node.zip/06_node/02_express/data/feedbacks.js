export default new Map([
  [
    '1',
    {
      title: 'Title 1',
      answers: ['yes', 'no', 'no', 'yes'],
    },
  ],
  [
    '2',
    {
      title: 'Title 2',
      answers: ['no', 'no', 'no', 'yes'],
    },
  ],
]);
